package Week4;

import java.util.ArrayList;
import java.util.List;

// Clone / HashSet / TreeSet
//public class Person implements Cloneable, Comparable{
//	int id;
//	String name;
//	List<String> address;
//	
//	public Person(int id, String name, List<String> address) {
//		this.id = id;
//		this.name = name;
//		this.address = address;
//	}
//	public int getId() {
//		return id;
//	}
//	public void setId(int id) {
//		this.id = id;
//	}
//	
//	public String getName() {
//		return name;
//	}
//	public void setName(String name) {
//		this.name = name;
//	}
//	public List<String> getAddress() {
//		return address;
//	}
//	public void setAddress(List<String> address) {
//		this.address = address;
//	}
//	
//	public Person clone() throws CloneNotSupportedException {
//		// Shallow copy
//		// return (Person) super.clone();
//		
//		// deep copy
//		Person rtn = (Person) super.clone();
//		if( this.address == null ) {
//			return rtn;
//		}
//		List<String> add = new ArrayList<String>();
//		if( this.address.size() != 0 )
//			for( String str: add )
//				add.add(str);
//		rtn.setAddress(add);
//		return rtn;
//	}
//	
//	@Override
//	public int hashCode() {
//		final int prime = 31;
//		int result = 1;
//		result = prime * result + ((address == null) ? 0 : address.hashCode());
//		result = prime * result + id;
//		result = prime * result + ((name == null) ? 0 : name.hashCode());
//		return result;
//	}
//	
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		Person other = (Person) obj;
//		if (address == null) {
//			if (other.address != null)
//				return false;
//		} else if (!address.equals(other.address))
//			return false;
//		if (id != other.id)
//			return false;
//		if (name == null) {
//			if (other.name != null)
//				return false;
//		} else if (!name.equals(other.name))
//			return false;
//		return true;
//	}
//	
//	@Override
//	public int compareTo(Object o) {
//		if( o != null && this.getClass() == o.getClass() ) {
//			Person p = (Person) o;
//			if( this.getId() != p.getId() )
//				return this.getId() - p.getId();
//			if( this.getName() != null ) {
//				if( p.getName() != null ) {
//					if( this.getName().compareTo(p.getName()) != 0 )
//						return this.getName().compareTo(p.getName());
//				}
//				else
//					return 1;
//			}
//		}
//		return -1;
//	}
//}


// immutable class
//public final class Person implements Cloneable{
//	final int id;
//	final String name;
//	final List<String> address;
//	
//	public Person(int id, String name, List<String> address) {
//		this.id = id;
//		this.name = name;
//		this.address = new ArrayList<>();
//		if( address != null && address.size() != 0 )
//			for( String str: address )
//				this.address.add(str);
//	}
//	
//	public int getId() {
//		return id;
//	}
//	
//	public String getName() {
//		return name;
//	}
//
//	public List<String> getAddress() {
//		if(this.address == null )
//			return null;
//		List<String> add = new ArrayList<String>();
//		if( this.address.size() != 0 )
//			for( String str: add )
//				add.add(str);
//		return add;
//	}
//	
//	public Person clone() throws CloneNotSupportedException {
//		return new Person( this.id, this.name, this.address );
//	}
//	
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		Person other = (Person) obj;
//		if (address == null) {
//			if (other.address != null)
//				return false;
//		} else if (!address.equals(other.address))
//			return false;
//		if (id != other.id)
//			return false;
//		if (name == null) {
//			if (other.name != null)
//				return false;
//		} else if (!name.equals(other.name))
//			return false;
//		return true;
//	}
//}


// Singleton
//public class Person implements Cloneable{
//	int id;
//	String name;
//	List<String> address;
//	static Person rtn;
//	
//	// Eager:
////	static {
////		List<String> address = new ArrayList<>();
////		address.add("Cali");
////		address.add("Chit");
////		address.add("nyc");
////		rtn = new Person(111, "Kaige", address );
////	}
////	
////	public static Person getInstance() {
////		return rtn;
////	}
//	
//	// Lazy:
//	public static Person getInstance() {
//		if( rtn == null ) {
//			List<String> address = new ArrayList<>();
//			address.add("Cali");
//			address.add("Chit");
//			address.add("nyc");
//			rtn = new Person(111, "Kaige", address );
//		}
//		return rtn;
//	}
//	
//	private Person(int id, String name, List<String> address) {
//		this.id = id;
//		this.name = name;
//		this.address = address;
//	}
//	
//	
//	
//	public int getId() {
//		return id;
//	}
//	
//	public String getName() {
//		return name;
//	}
//
//	public List<String> getAddress() {
//		if(this.address == null )
//			return null;
//		List<String> add = new ArrayList<String>();
//		if( this.address.size() != 0 )
//			for( String str: add )
//				add.add(str);
//		return add;
//	}
//	
//	public Person clone() throws CloneNotSupportedException {
//		return this;
//	}
//	
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		Person other = (Person) obj;
//		if (address == null) {
//			if (other.address != null)
//				return false;
//		} else if (!address.equals(other.address))
//			return false;
//		if (id != other.id)
//			return false;
//		if (name == null) {
//			if (other.name != null)
//				return false;
//		} else if (!name.equals(other.name))
//			return false;
//		return true;
//	}
//}
//Enum
enum Person{
	Person();
	private int id;
	private String name;
	private List<String> address;
	
	Person(){
		this.id = 111;
		this.name = "Kaige";
		this.address = new ArrayList<>();
		address.add("Cali");
		address.add("Chit");
		address.add("NYC");
	}
	
	public int getId() {
		return this.id;
	}
	
	public String getName() {
		return this.name;
	}
	
	public List<String> getAddress() {
		if( this.address == null )
			return null;
		List<String> rtn = new ArrayList<>();
		for( String str: this.address ) {
			rtn.add(str);
		}
		return rtn;
	}
}