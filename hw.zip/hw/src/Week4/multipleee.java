package Week4;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class multipleee {
	public static void main(String[] args) throws InterruptedException {
		Task a = new Task();
		Thread t1 = new Thread(()->{
			for( int i = 0; i < 1000; ++i ) {
				a.add();
			}
		}) ;
		Thread t2 = new Thread(()->{
			for( int i = 0; i < 1000; ++i ) {
				a.minus();
			}
		}) ;
		t1.start();
		t2.start();
		t1.join();
		t2.join();
		System.out.println(a.x.size());
		System.out.println(a.a);
	}
}

class Task {
	List<Integer> x = new ArrayList<Integer>();
	int a = 0;
//	Lock lock = new ReentrantLock();
//	
//	Condition add = lock.newCondition();
//	Condition remove = lock.newCondition();
//	
//	public void add() {
//		while( true ) {
//			try {
//				if( lock.tryLock(2000, TimeUnit.MILLISECONDS)) {
//					if( x.size() < 10 ) {
//						x.add(x.size());
//						remove.signalAll();
//						lock.unlock();
//						break;
//					}else {
//						add.await();
//						lock.unlock();
//					}
//				}
//			} catch (InterruptedException e) {
//				System.out.println("add error");
//				lock.unlock();
//			}
//		}
//	}
//	
//	public void minus(){
//		while( true ) {
//			try {
//				if( lock.tryLock(2000, TimeUnit.MILLISECONDS)) {
//					if( x.size() > 0 ) {
//						x.remove(0);
//						add.signalAll();
//						lock.unlock();
//						break;
//					}else {
//						remove.await();
//						lock.unlock();
//					}
//				}
//			} catch (InterruptedException e) {
//				System.out.println("remove error");
//				lock.unlock();
//			}
//		}
//	}
	
	public void add() {
		synchronized(this) {
			if( x.size() < 10 ) {
				x.add(x.size());
				a++;
			}
			else {
				System.out.println("exceed");
			}
		}
	}
	
	public void minus() {
		synchronized(this) {
			if( x.size() > 0 ) {
				x.remove(0);
				a++;
			}
		}
	}
}
