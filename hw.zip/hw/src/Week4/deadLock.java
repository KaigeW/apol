package Week4;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class deadLock {
	public static void main(String[] args) throws InterruptedException {
		show a = new show();
		Thread t1 = new Thread(()->{
				a.add();
		}); 
		Thread t2 = new Thread(()->{
				a.remove();
		}); 
		t1.start();
		t2.start();
		t1.join();
		t2.join();
		System.out.println(a.seats.size());
	}
}

class show{
	List<String> seats = new ArrayList<>();
	Object remove = new Object();
	Object add = new Object();
	
//	public void add() {
//		while( true ) {
//			synchronized (remove) {
//				System.out.println("removeLocked ADD");
//				synchronized (add) {
//					System.out.println("addLocked ADD");
//				}
//			}
//		}
//	}
//	
//	public void remove() {
//		while( true ) {
//			synchronized( add ) {
//				System.out.println("addLocked REV");
//				synchronized ( remove ) {
//					System.out.println("removeLocked REV");
//				}
//			}
//		}
//	}
	
	
//	Lock add = new ReentrantLock();
//	Lock remove = new ReentrantLock();
	
	public void add() {
		int a = 100;
		while( --a > 0 ) {
			synchronized (remove) {
				System.out.println("removeLocked ADD");
				synchronized (add) {
					System.out.println("addLocked ADD");
				}
			}
		}
	}

	public void remove() {
		int a = 100;
		while( --a > 0 ) {
			synchronized( remove ) {
				System.out.println("addLocked REV");
				synchronized ( add ) {
					System.out.println("removeLocked REV");
				}
			}
		}
	}
	
}
