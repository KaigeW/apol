package Week4;

// https://www.hackerrank.com/challenges/java-exception-handling-try-catch/problem
// 
//import java.io.*;
//import java.util.*;
//
//public class Solution {
//    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        try{
//            int a = sc.nextInt();
//            int b = sc.nextInt();
//            System.out.println(a/b);
//        }
//        catch(InputMismatchException e){
//            System.out.println("java.util.InputMismatchException");
//        }
//        catch(ArithmeticException e){
//            System.out.println("java.lang.ArithmeticException: / by zero");
//        }
//    }
//}

// https://www.hackerrank.com/challenges/java-hashset/problem
//
//import java.io.*;
//import java.util.*;
//import java.text.*;
//import java.math.*;
//import java.util.regex.*;
//
//public class Solution {
//
// public static void main(String[] args) {
//        Scanner s = new Scanner(System.in);
//        int t = s.nextInt();
//        String [] pair_left = new String[t];
//        String [] pair_right = new String[t];
//        
//        for (int i = 0; i < t; i++) {
//            pair_left[i] = s.next();
//            pair_right[i] = s.next();
//        }
//
////Write your code here
//        Set<String> set = new HashSet<>();
//        for( int i = 0; i < pair_left.length; ++i ){
//            set.add(pair_left[i]+' '+pair_right[i]);
//            System.out.println(set.size());
//        }
//   }
//}

// https://www.hackerrank.com/challenges/java-stack/problem
//
//import java.util.*;
//class Solution{
//	
//	public static void main(String []argh)
//	{
//		Scanner sc = new Scanner(System.in);
//		while (sc.hasNext()) {
//			String input=sc.next();
//            //Complete the code
//            char[] str = input.toCharArray();
//            Stack<Character> check = new Stack<>();
//            boolean real = true;
//            if( str.length % 2 != 0 ){
//                System.out.println(false);
//                continue;
//            }
//            for( char c: str ){
//                if( c == '(' || c == '{' || c == '[' )
//                    check.push(c);
//                else if( c == ')' && (check.size() == 0 || check.pop() != '(') ){
//                        real = false;
//                        break;
//                }else if( c == ']' && (check.size() == 0 || check.pop() != '[') ){
//                        real = false;
//                        break;
//                }else if( c == '}' && (check.size() == 0 || check.pop() != '{') ){
//                        real = false;
//                        break;
//                }
//            }
//            if( real && check.size() != 0)
//                real = true;
//            System.out.println(real);
//		}
//		
//	}
//}

// https://www.hackerrank.com/challenges/java-comparator/problem
// 
//import java.util.*;
//class Checker implements Comparator<Player>{
//    public int compare(Player p1, Player p2){
//        if( p1.score == p2.score ){
//            return p1.name.compareTo(p2.name);
//        }
//        else{
//            return p2.score - p1.score;
//        }
//    }
//}
//// Write your Checker class here
//
//class Player{
//    String name;
//    int score;
//    
//    Player(String name, int score){
//        this.name = name;
//        this.score = score;
//    }
//}
//
//class Solution {
//
//    public static void main(String[] args) {
//        Scanner scan = new Scanner(System.in);
//        int n = scan.nextInt();
//
//        Player[] player = new Player[n];
//        Checker checker = new Checker();
//        
//        for(int i = 0; i < n; i++){
//            player[i] = new Player(scan.next(), scan.nextInt());
//        }
//        scan.close();
//
//        Arrays.sort(player, checker);
//        for(int i = 0; i < player.length; i++){
//            System.out.printf("%s %s\n", player[i].name, player[i].score);
//        }
//    }
//}

// https://www.hackerrank.com/challenges/java-factory/problem
//
//import java.util.*;
//import java.security.*;
//interface Food {
//	 public String getType();
//	}
//	class Pizza implements Food {
//	 public String getType() {
//	 return "Someone ordered a Fast Food!";
//	 }
//	}
//
//	class Cake implements Food {
//
//	 public String getType() {
//	 return "Someone ordered a Dessert!";
//	 }
//	}
//	class FoodFactory {
//		public Food getFood(String order) {
//
////Write your code here
//if(order.equalsIgnoreCase("cake")){
//    return new Cake();
//}
//else if( order.equalsIgnoreCase("Pizza")){
//    return new Pizza();
//}
//return null;
//}//End of getFood method
//
//	}//End of factory class
//
//	public class Solution {
//
//	 public static void main(String args[]){
//			Do_Not_Terminate.forbidExit();
//
//		try{
//
//			Scanner sc=new Scanner(System.in);
//			//creating the factory
//			FoodFactory foodFactory = new FoodFactory();
//	
//			//factory instantiates an object
//			Food food = foodFactory.getFood(sc.nextLine());
//	
//			
//			System.out.println("The factory returned "+food.getClass());
//			System.out.println(food.getType());
//		}
//		catch (Do_Not_Terminate.ExitTrappedException e) {
//			System.out.println("Unsuccessful Termination!!");
//		}
//	 }
//
//	}
//	class Do_Not_Terminate {
//		 
//	    public static class ExitTrappedException extends SecurityException {
//
//			private static final long serialVersionUID = 1L;
//	    }
//	 
//	    public static void forbidExit() {
//	        final SecurityManager securityManager = new SecurityManager() {
//	            @Override
//	            public void checkPermission(Permission permission) {
//	                if (permission.getName().contains("exitVM")) {
//	                    throw new ExitTrappedException();
//	                }
//	            }
//	        };
//	        System.setSecurityManager(securityManager);
//	    }
//	}	
		
// https://www.hackerrank.com/challenges/java-priority-queue/problem
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Scanner;
//import java.util.PriorityQueue;
//
///*
// * Create the Student and Priorities classes here.
// */
//class Student implements Comparable<Student>{
//    String name;
//    double GPA;
//    int id;
//
//    Student(String name, double GPA, int id){
//        this.name = name;
//        this.GPA = GPA;
//        this.id = id;
//    }
//    
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public double getGPA() {
//        return GPA;
//    }
//
//    public void setGPA(double gPA) {
//        GPA = gPA;
//    }
//
//    public int getId() {
//        return id;
//    }
//
//    public void setId(int id) {
//        this.id = id;
//    }
//
//    public String toString(){
//        return this.name + " " + this.GPA + " " + this.id;
//    }
//
//    @Override
//    public int compareTo(Student o) {
//        if( this.GPA == o.GPA) {
//            if( this.name == null || o.name == null ) {
//                if( this.name == null && o.name != null )
//                    return 1;
//                if( this.name != null && o.name == null )
//                    return -1;
//                if( this.name == null && o.name == null )
//                    return this.id - o.id;
//            }
//            if( this.name.equals(o.name) ) {
//                return this.id - o.id;
//            }
//            else
//                return this.name.compareTo(o.name);
//        }
//        else
//            return (this.GPA - o.GPA) < 0? 1 : -1;
//    }
//}
//
//class Priorities{
//    PriorityQueue<Student> list;
//    
//    Priorities(){
//        list = new PriorityQueue<>();
//    }
//
//    public List<Student> getStudents( List<String> input ){
//        for( String str: input ){
//            if( str.equals("SERVED") )
//                this.dropStudent();
//            else if( str.startsWith("ENTER") )
//                this.addStudent(str);
//            else
//                return new ArrayList<Student>();
//        }
//        List<Student> remain = new ArrayList<>();
//        Student ref;
//        while( (ref = list.poll()) != null )
//            remain.add(ref);
//        return remain;
//    }
//
//    private void addStudent(String str) {
//        String[] keys= str.split(" ");
//        String name = keys[1];
//        double gpa = Double.parseDouble(keys[2]);
//        int id = Integer.parseInt(keys[3]);
//        list.add(new Student(name, gpa, id));
//    }
//
//    private void dropStudent() {
//        if( !list.isEmpty())
//            list.remove();
//    }
//}
//
//public class Solution {
//    private final static Scanner scan = new Scanner(System.in);
//    private final static Priorities priorities = new Priorities();
//    
//    public static void main(String[] args) {
//        int totalEvents = Integer.parseInt(scan.nextLine());    
//        List<String> events = new ArrayList<>();
//        
//        while (totalEvents-- != 0) {
//            String event = scan.nextLine();
//            events.add(event);
//        }
//        
//        List<Student> students = priorities.getStudents(events);
//        
//        if (students.isEmpty()) {
//            System.out.println("EMPTY");
//        } else {
//            for (Student st: students) {
//                System.out.println(st.getName());
//            }
//        }
//    }
//}

// https://www.hackerrank.com/challenges/java-regex/problem
//
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
//import java.util.Scanner;
//
//class Solution{
//
//    public static void main(String[] args){
//        Scanner in = new Scanner(System.in);
//        while(in.hasNext()){
//            String IP = in.next();
//            System.out.println(IP.matches(new MyRegex().pattern));
//        }
//
//    }
//}
//
////Write your code here
//class MyRegex{
//    String pattern = "([0-9]|[0-9][0-9]|[0-1][0-9][0-9]|[0-2][0-4][0-9]|25[0-5])\\.([0-9]|[0-9][0-9]|[0-1][0-9][0-9]|[0-2][0-4][0-9]|25[0-5])\\.([0-9]|[0-9][0-9]|[0-1][0-9][0-9]|[0-2][0-4][0-9]|25[0-5])\\.([0-9]|[0-9][0-9]|[0-1][0-9][0-9]|[0-2][0-4][0-9]|25[0-5])";
//}