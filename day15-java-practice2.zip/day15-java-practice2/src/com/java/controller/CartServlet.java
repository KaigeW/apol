package com.java.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/remove")
public class CartServlet extends HttpServlet {
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter pw = resp.getWriter();
		HttpSession ses = req.getSession();
		List<String> cart = (List<String>) ses.getAttribute("cart");
		for(String str: req.getParameterValues("remove")) {
			cart.remove(str);
		}
		pw.println("<a href=\"http://localhost:8080/day15-java-practice2/bookStore.html\">main</a>");
		pw.println("Remove book success!");
		ses.setAttribute("cart", cart);
		if( cart.size() != 0 ) {
			pw.println("You have ");
			for( String str: cart ) {
				pw.println( str );
			}
			pw.println("in your cart");
		}else {
			pw.println("Your cart is empty now!");
		}

	}
}
