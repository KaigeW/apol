package com.java.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Optional;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet{
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
//		System.out.println(req.getContextPath()); // project name
//		System.out.println(req.getRequestURI()); // project_name/servlet_name
//		System.out.println(req.getQueryString()); // anything after question mark
//		System.out.println(req.getRequestURL()); // complete url
//		System.out.println(req.getPathInfo()); // 
//		System.out.println(req.getServletPath());
//		System.out.println(req.getContentType()); // type of data that is being sent
//		System.out.println(req.getContentLength()); // length 
//		Enumeration<String> enumeration = req.getHeaderNames();
//		while( enumeration.hasMoreElements()) {
//			String header = enumeration.nextElement();
//			System.out.println(header+":"+req.getHeader(header));
//		}
//		System.out.println(req.getLocale());
		
		PrintWriter pw = resp.getWriter();
		String username = (String) req.getParameter("uname");
		String password = (String) req.getParameter("pword");
		if( username.equals("admin") && password.equals("admin") ) {
			HttpSession session = req.getSession();
			session.setAttribute("username", username);
			resp.sendRedirect("./bookStore.html");
		}else {
			pw.println("Please check your username and password combination");
		}
		pw.close();
	}
}
