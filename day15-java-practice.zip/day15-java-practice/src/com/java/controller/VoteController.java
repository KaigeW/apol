package com.java.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/vote")
public class VoteController extends HttpServlet {
	
	public static Map<String, Integer> votes;
	public static List<String> IP;
	public List<String> ip = new ArrayList<>();
	
	static {
		votes = new HashMap<String, Integer>();
		IP = new ArrayList<String>();
		votes.put("noodles", 0);
		votes.put("rice", 0);
		votes.put("meat", 0);
	}
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter pw = resp.getWriter();
		for( String str: votes.keySet() ) {
			pw.println("str: " + votes.get(str));
		}
		pw.close();
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter pw = resp.getWriter();
		String ipAddress = req.getRemoteAddr();
		if( !IP.contains(ipAddress) ) {
			for(String str: req.getParameterValues("food")) {
				votes.put(str, votes.get(str) + 1);
			}
			pw.println("Vote success!");
			for( String str: votes.keySet() ) {
				pw.println(str + ": " + votes.get(str));
			}
			IP.add(ipAddress);
		}
		else {
			pw.println("You voted before!");
			for( String str: votes.keySet() ) {
				pw.println("str: " + votes.get(str));
			}
		}
		pw.close();
	}
}
